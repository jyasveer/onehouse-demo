import UploadFile from "./upload-file/UploadFile";
import Configure from "./configure/Configure";

export {
    UploadFile,
    Configure
}